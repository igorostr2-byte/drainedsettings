# Hey there! I'm Lioren, the creator of this texture pack. 

## DOs

- You may use this pack for personal use.
- You may use this pack in videos, streams, screenshots, social media posts, and similar content.
- You may share unmodified copies of this pack, provided that proper credit is given and the included files (`README.md`, and `LICENSE`) are retained.
- You may create private modifications of this pack for your own use.

## DON'Ts

- Do not claim that this pack or its assets were created entirely by you.
- Do not remove, alter, or misrepresent existing credits or copyright notices.
- Do not redistribute modified versions of this pack without permission.

## Additional Attribution

You can credit me by:
- Linking to the project's Modrinth page.
- Mentioning my Discord handle: `@iamraj69`
- Linking to my GitHub: https://github.com/itsMeRaj69

## Want to reach me?

- Email: contact@lioren.me
- Discord: @iamraj69
- Telegram: @iamraj69

**Thank you for reading this far! Have a great day! 🤍**
